'use strict'

module.exports = (logSources, printer) => {
	const arr = [];
	console.log("FROM SYNC CALL");
	for (var i = 0; i < logSources.length; i++) {
		arr.push(logSources[i].pop())
	}
	arr.sort((log1, log2) => {
		const date1 = new Date(log1.date)
		const date2 = new Date(log2.date)
		return date1 - date2
	})

	for (var i = 0; i < logSources.length; i++) {
		printer.print(arr[i])
	}



}