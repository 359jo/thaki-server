'use strict'

module.exports = (logSources, printer) => {
	const arr = []
	console.log("FROM ASYNC CALL");
	
	const getObj = async () => {
		for (let i = 0; i < logSources.length; i++) {
			const obj = await logSources[i].popAsync()
			arr.push(obj)
		}

		arr.sort((log1, log2) => {
			const date1 = new Date(log1.date)
			const date2 = new Date(log2.date)
			return date1 - date2
		})

		for (let i = 0; i < arr.length; i++) {
			printer.print(arr[i]);
		}
	}
	getObj()
}


/*

	const date2 = async (cb)=>{
		const asyncHelp = await cb()
		return asyncHelp.date
	}
	const asyncCaller = async (cb)=>{
		const asyncCall = await cb()
		return asyncCall.date
	}

	logSources.sort((log1, log2) => {
		const d1 = new Date(date1(log1.popAsync()))
		const d2 = new Date(date2(log2.popAsync()))
		return d1 - d2
	})


	let resultOfAsyncLogs = await Promise.all(logSources.map(item => item.popAsync()))
	resultOfAsyncLogs.sort(function (item1, item2) {
		return item1.popAsync() - item2.popAsync().;
	});
	
*/